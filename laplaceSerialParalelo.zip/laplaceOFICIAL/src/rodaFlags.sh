#!/bin/bash

# ======================================
# Script para compilar com varias flags
#
# v=0.1    
#
# Autor: Eu 
#
# =====================================


  
       cp laplaceserial.c laplace.c
       sed -i "s/XYX/-w/g" laplace.c
       gcc -pg -g laplace.c -lm -fopenmp -o laplace.x
       date +%r > TS.dat
       ./laplace.x
       date +%r >> TfS.dat
       gprof laplace.x gmon.out > Profiling_Novo_SemFlags.dat

