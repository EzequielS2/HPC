#!/bin/bash



for i in $(seq 0 2)
do
	t1=$(date "+%s")
	./laplaceO$i.exe
	t2=$(date "+%s")

	tempo=$(($t2-$t1))
	
	echo $i $tempo >> tempos-flagO.dat

done 


