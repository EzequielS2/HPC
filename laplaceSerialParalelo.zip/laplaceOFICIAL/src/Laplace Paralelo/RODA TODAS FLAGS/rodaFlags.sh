#!/bin/bash




   for i in  $(seq 0 3)
     do
       cp laplaceparalelo.c laplace.c
       sed -i "s/XYX/$i/g" laplace.c
       gcc -pg -g -O$i laplace.c -lm -fopenmp -o laplace.x
       date +%r > TS$i.dat
       time ./laplace.x
       date +%r >> TS$i.dat
       gprof laplace.x gmon.out > profilingParaleloFlagO$i.dat

 done
