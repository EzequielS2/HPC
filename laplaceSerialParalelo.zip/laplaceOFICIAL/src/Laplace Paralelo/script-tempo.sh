#!/bin/bash

 

gcc -fopenmp -o LaplaceParalelo.exe laplaceparalelo.c -O0 -lm

	
	t1=$(date "+%s")
	./LaplaceParalelo.exe
	t2=$(date "+%s")
	tempo=$(($t2-$t1))
	echo 0 $tempo >> tempo-Serial_FlagO0.dat

	
