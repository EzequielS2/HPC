#!/bin/bash

gcc -fopenmp -o LaplaceParalelo.exe LaplaceParalelo.c -O1 -lm

for i in $(seq 0 3)

do 
	
	t1=$(date "+%s")
	./LaplaceParalelo.exe
	t2=$(date "+%s")
	tempo=$(($t2-$t1))
	echo $i $tempo >> tempo_Paralelo-FlagO1.dat
done
	
