#!/bin/bash

gcc -fopenmp -o laplace.exe laplaceserial.c -O1 -lm

for i in $(seq 1 8)

do 
	export OMP_NUM_THREADS=$i
	
	t1=$(date "+%s")
	./laplace.exe
	t2=$(date "+%s")
	tempo=$(($t2-$t1))
	echo $i $tempo >> tempo-SerialFlagO1.dat
done
	
