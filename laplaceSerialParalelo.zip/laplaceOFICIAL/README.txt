Aqui se encontra o programa principal.

Este programa principal foi feito em serial, que est� em src. Ele cria as cond��es 
de contorno e resolve a edp armazenando os valores em V. 

A malha � 10000x10000, e toler�ncia m�xima � 0,001. 


16/11/2021